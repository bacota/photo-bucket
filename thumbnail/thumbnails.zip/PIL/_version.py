# Master version for Pillow
__version__ = '5.2.0'
